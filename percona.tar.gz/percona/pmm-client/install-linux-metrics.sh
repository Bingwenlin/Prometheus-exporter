#!/bin/bash

currDir="/usr/local/percona/pmm-client"

check_port() {
        echo "正在检测端口。。。"
        netstat -tlpn | grep "\b$1\b"
}

check_pstree(){
	if command -v pstree >/dev/null 2>&1; then 
	  echo 'exists pstree' 
	else 
	  echo 'no exists pstree, we will install psmisc' 
	  yum install psmisc -y
	fi
}

install_linux_service() {

    if check_port 42000; then
        echo "端口存在"
    	exit 1
    fi
	String=$(pstree | head -n 1 | awk -F'-' '{print $1}')

	case $String in
	    init)  
	    	cp ${currDir}/pmm-linux-metrics-42000.conf /etc/init/
	    	start pmm-linux-metrics-42000
	    ;;
	    systemd)  
	    	cp ${currDir}/pmm-linux-metrics-42000.service /etc/systemd/system/
	    	systemctl enable pmm-linux-metrics-42000
	    	systemctl start pmm-linux-metrics-42000
	    ;;
	    *)  exit
	    ;;
	esac
}

install_mysql_service() {
    if check_port 42002; then
        echo "端口存在"
    	exit 1
    fi
    cp ${currDir}/pmm-mysql-metrics-42002.service /etc/systemd/system/
    systemctl enable pmm-mysql-metrics-42002
    systemctl start pmm-mysql-metrics-42002
}

check_pstree

case $1 in
    linux-metrics)
        install_linux_service
    ;;
    mysql-metrics)
        install_mysql_service
    ;;
    *) exit
    ;;
esac
